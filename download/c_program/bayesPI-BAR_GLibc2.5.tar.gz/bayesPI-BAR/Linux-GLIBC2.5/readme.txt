This folder contains the demo package for BayesPI-BAR. The demo implements the full pipeline and will reproduce the results from the paper if run on the same dataset. The dataset which comes with the demo is a small sample.

The software prerequisites of the demo are:
1) R (http://www.r-project.org/). The script will also try to install the "stringr" R package if it isn't already installed; this will require an Internet connection. On Windows, you'll need to add the R binary folder to PATH or specify the full path to Rscript.exe in the batch file.
2) Perl. On Windows, only Strawberry Perl will work. Perl executable must be on PATH.
3) The demo will only work on an x64 OS.

To run the demo, start the "runDemo.sh" bash script ("runDemo.bat" on Windows) from the "demo" folder. A run with default parameters takes about 7 minutes on 3,7 GHz Quad-Core Intel Xeon E5.

The program loads all "*.mlp" files from the "pwm" folder and uses them as the set of PWMs to work with. .mlp format is a format of PWM which is produced by the BayesPI2 software. An R script "fasta2mlp.r" is included in the folder "code/r" which can transform a fasta-like PWM format into .mlp files. The dataset used in the paper was downloaded from http://compbio.mit.edu/encode-motifs/motifs.txt , in the fasta-like format.

The mutations are loaded from "seq/snps_ref.fasta" and "seq/snps_alt.fasta" which should contain the reference and alternative sequences. The corresponding sequences' names should be identical. The set of chemical potentials is loaded from the "potentials" file, which should contain one nonpositive number per line.

First, the script computes delta-dbA scores for the input dataset. It is saved into "tmp" folder. Then the scores are integrated into the final ranking, which is saved in "rankings" folder as one tab-separated file per SNP. These files contain the following columns:
change: whether the affinity change caused to the TF by the SNP is positive or negative;
rank: the rank of the TF by decreasing strength of affinity change (the rankings are separate for positive and negative changes);
fileName: the PWM file name;
med.p.ref: median p-value for dbA of the PWM to the reference sequence;
med.p.alt: median p-value for dbA of the PWM to the alternative sequence;
score: the integrated score on which the ranking is based (it is not centered on zero so it may change sign arbitrarily)
mean.ddba: the mean of delta-dbA scores for all chemical potentials.
mean.ddba.pvalue: p-value of the mean.ddba computed across the entire dataset of all mutations/PWMs. -normalizeDbA is recommended for using this value

The demo script accepts the following command line options:
-cut <number>          the p-value cutoff. dbA scores with p-value greater than this will be considered insignificant and set to zero. Default: 0.05
-noRecompute           do not compute the delta-dbA scores, take them from the "tmp" folder and only run the integration
-iter <number>         iteration count to compute background binding affinity for dbA scores. Default: 1000
-top <number>          number of top ranked TFs to save in the results. Default: 10
-seqRef <file name>    name of the FASTA file containing reference sequences of all mutations. Default: seq/snps_ref.fasta
-seqAlt <file name>    name of the FASTA file containing alternate (mutated) sequences of all mutations. Default: seq/snps_alt.fasta
-parallel <number>     number of parallel processes to spawn when computing delta-dbA scores. Default: 20
-resample              shuffle input sequences separately for each SNP/PWM/potential combination instead of shuffling only once.
-normalizeDbA <number> normalization method for dbA scores:
                           0 (default): do not use normalization
                           1: divide each dbA score by the standard deviation of the corresponding background affinities
                           2: relative difference, that is to divide each dbA score by sqrt((1 + affinity)^2 + (1 + mean_background_affinity)^2)
-noRecalcDbA           skip recalculating dbA scores. delta-dbA scores will still be recomputed
-onlyRef               do not perform bayesPI-BAR mutation analysis. Instead, compute dbA scores and p-values for reference sequences only
-integration <method>  use the specified method for integration of delta-dbA scores across chemical potentials. <method> can be one of the following:
                           'pca': the default method which finds extreme values of the first principal component of delta-dbA scores
                           'mean': the score is the mean of delta-dbA scores
                           'median.ddba': the score is the median of delta-dbA scores
                           'median.rank': the resulting rank of a PWM is the median of its ranks computed based on all chemical potentials
                           'rra': uses the Robust Rank Aggregation algorithm to join individual ranks based on all chemical potentials into the final rank. This requires the RobustRankAggreg library to be installed in R
                           'pot<N>' where N = 1..<number of chemical potentials>: use only the specified chemical potential
-pSelect <number>      additionally filter the results based on mean delta-dbA p-value, which is computed with respect to the whole dataset of all mutations. This allows selecting only the PWMs which are affected the most overall
