if(!("stringr" %in% installed.packages()))
  install.packages("stringr", repos = "http://cran.us.r-project.org")

if(!file.exists("pwm"))
  stop("Please run this script from the demo folder")

source("code/r/misc.R")


stdEpsilon = 0.001

# default parameter values
pCut = 0.05
pMeanDdbA = NA
onlyIntegrate = F
calcDbA = T
shuffleIters = 10000
top = 10
parallel = 20
sampleOnce = T
seqRef = "seq/snps_ref.fasta"
seqAlt = "seq/snps_alt.fasta"
integration = "pca"
seed = 1
useFiltering = T
normalizeDbA = 0
onlyRef = F

i = 1
while (i <= length(args)) {
  arg = args[i]
  if(substr(arg, 1, 1) != "-")
    stop(paste0("could not understand command line argument: ", arg))
  
  argName = substr(arg, 2, nchar(arg))
  if(argName == "cut") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    pCut = as.numeric(args[i])
    if(is.na(pCut) || pCut < 0 || pCut > 1)
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("p-value cutoff set to", pCut, "\n")
  } else if(argName == "noRecompute") {
    onlyIntegrate = T
    cat("will only perform integration of delta-dbA scores\n")
  } else if(argName == "iter") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    shuffleIters = as.integer(args[i])
    if(is.na(shuffleIters))
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("number of background shuffling iterations set to", shuffleIters, "\n")
  } else if(argName == "top") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    top = as.integer(args[i])
    if(is.na(top))
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("number of PWMs to save in the rankings set to", top, "\n")
  } else if(argName == "seqRef") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    seqRef = args[i]
    cat("reference sequence file set to", seqRef, "\n")
  } else if(argName == "seqAlt") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    seqAlt = args[i]
    cat("alternate sequence file set to", seqAlt, "\n")
  } else if(argName == "parallel") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    parallel = as.integer(args[i])
    if(is.na(parallel) || parallel < 1)
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("number of parallel processes set to", parallel, "\n")
  } else if(argName == "integration") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    integration = args[i]
    cat("delta-dbA scores integration method set to", integration, "\n")
  } else if(argName == "seed") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    seed = as.integer(args[i])
    if(is.na(seed))
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("random seed set to", seed, "\n")
  } else if(argName == "noFilter") {
    useFiltering = F
    cat("filtering is disabled\n")
  } else if(argName == "normalizeDbA") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    normalizeDbA = as.integer(args[i])
    if(is.na(normalizeDbA))
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("dbA normalization method set to", normalizeDbA, "\n")
  } else if(argName == "noRecalcDbA") {
    calcDbA = F
    cat("dbA recalculation is disabled. dbA scores will be read from tmp/ folder\n")
  } else if(argName == "onlyRef") {
    onlyRef = T
    cat("delta-dbA calculation is disabled. Will only compute dbA values for reference sequence and put them into tmp/ folder\n")
  } else if(argName == "pSelect") {
    if(i == length(args))
      stop(paste0("argument ", arg, " needs a parameter"))
    
    i = i + 1
    pMeanDdbA = as.numeric(args[i])
    if(is.na(pMeanDdbA))
      stop(paste0("wrong value for argument ", arg, ": ", args[i], "\n"))
    
    cat("p-value for post-filtering results based on delta-dbA magnitudes set to", pMeanDdbA, "\n")
  } else {
    stop("unknown command line argument: ", arg)
  }
  
  i = i + 1
}


if(!calcDbA && onlyIntegrate)
  stop("both -noRecompute and -noRecalcDbA are specified. Unsure what to do")

if(!useFiltering && (pCut != 0.05 || !is.na(pMeanDdbA)))
  stop("both -noFilter and one of the filtering arguments are specified. Unsure what to do")

if(onlyRef && seqAlt != "seq/snps_alt.fasta")
  stop("both -onlyRef and -seqAlt are specified. Unsure what to do")

if(normalizeDbA != 0 && onlyIntegrate)
  stop("both -noRecompute and -normalizeDbA are specified. Unsure what to do")


if(useFiltering)
{
  cat("p-value cutoff:", pCut, "\n")
} else {
  cat("No filtering will be applied\n")
}

if(onlyIntegrate)
{
  calcDbA = F
}

if(onlyRef)
{
  cat("Performing dbA computation for reference sequences only:", seqRef, "\n")
} else {
  cat("Reference FASTA:", seqRef, "\n")
  cat("Alternate FASTA:", seqAlt, "\n")
}

refSeq = readLines(seqRef)
seqNames = refSeq[grep("^>", refSeq)]
seqNames = sub("^>", "", seqNames)
dups = duplicated(seqNames)
if(sum(dups) > 0)
  stop(paste0("Duplicated sequence names found: ", paste(unique(seqNames[dups]), collapse = ", ")))

numMuts = length(seqNames)
if(onlyRef)
{
  cat(numMuts, "sequences selected\n")
} else {
  cat(numMuts, "alternate-reference sequence pairs selected\n")
}

pwmFiles = dir("pwm", "*.\\.mlp$")
numPWMs = length(pwmFiles)
cat(numPWMs, "PWMs selected\n")

potentials = as.integer(readLines("potentials"))
cat(length(potentials), "chemical potentials selected:", potentials, "\n")

if(calcDbA)
{
  cat("Computing dbA scores for selected sequences, PWMs and chemical potentials...\n")
  cat("Iterations count for background affinity computation:", shuffleIters, "\n")
  cat("Running in", parallel, "parallel processes\n")
  cat("Shuffle sequences once:", sampleOnce, "\n")
  altSeed = seed
  cat("Seed for reference:", seed, ", for alternate:", altSeed, "\n")
  
  quoteFile = function(fileName)
  {
    return(paste0("\"", fileName, "\""))
  }
  
  calcAllAffinities = function(pot, seqFile, resFolder, seed)
  {
    optPot = if(pot == 0) 0 else 1
    
    leftOvers = dir("pwm", "*_bindingP_*")
    for(l in leftOvers)
      file.remove(file.path("pwm", l))  
    
    system2("perl", c("code/perl/randomBackground_affinity_in_c_april2015.pl", "-numP", parallel, "-loops", shuffleIters, "-seqfile", seqFile,
                      "-psamFolder pwm", "-potential", optPot, "-override_potential", pot, "-seed", seed),
            stdout=NULL, stderr=NULL)
    
    
    res = NULL    
    
    for(pwm in pwmFiles)
    {      
      p0File = file.path("pwm", paste0(pwm, "_bindingP_0"))
      file.rename(p0File, file.path(resFolder, basename(p0File)))
      bgFile = paste0(p0File, "_randomBackground_", shuffleIters)
      bgOutFile = file.path(resFolder, basename(bgFile))
      file.rename(bgFile, bgOutFile)
    }
  }
  
  if(file.exists("tmp"))
    unlink("tmp", recursive = T)
    
  dir.create("tmp")
  
  for(i in 1:length(potentials))
  {
    pot = potentials[i]
    cat("Chemical potential =", pot, "\n")
    potDir = file.path("tmp", paste0("potential", pot))
    if(file.exists(potDir))
      unlink(potDir, recursive = T)
    
    dir.create(potDir)
    refDir = file.path(potDir, "ref")
    dir.create(refDir)
    altDir = file.path(potDir, "alt")
    dir.create(altDir)
    
    cat("Computing dbA scores for", length(pwmFiles), "PWMs and", numMuts, "reference sequences\n")
    calcAllAffinities(pot, seqRef, refDir, seed)
    
    if(!onlyRef) {
      cat("Computing dbA scores for", length(pwmFiles), "PWMs and", numMuts, "alternate sequences\n")
      calcAllAffinities(pot, seqAlt, altDir, altSeed)
    }
  }
} else {
  cat("dbA re-computation skipped\n")
}


normalizeDbA2 = function(rawDbA, backgroundStd)
{
  eps = median(backgroundStd) * 0.1
  backgroundStd = pmax(backgroundStd, eps)
  return(rawDbA / backgroundStd)
}


if(!onlyIntegrate)
{
  if(onlyRef)
  {
    cat("Joining the dbA scores and p-values\n")
    if(normalizeDbA == 1)
    {
      cat("Normalizing dbA scores using standard deviations\n")
    } else if (normalizeDbA == 2) {
      cat("Normalizing dbA scores using relative difference\n")
    } else {
      cat("Using raw dbA scores\n")
    }
    
    for(i in 1:length(potentials))
    {
      pot = potentials[i]
      cat("Chemical potential =", pot, "\n")
      
      potDir = file.path("tmp", paste0("potential", pot))
      refDir = file.path(potDir, "ref")
      
      dbAs = NULL
      ps = NULL
      
      for(j in 1:length(pwmFiles))
      {
        pwm = pwmFiles[j]
        
        refRes = read.table(file.path(refDir, paste0(pwm, "_bindingP_0_randomBackground_", shuffleIters)), sep = "\t", stringsAsFactors = F, header = T, comment.char = "", 
                            check.names = F)
        
        refRes = refRes[order(refRes$ID),]
        
        pIdx = 5
        dbAIdx = 4
        stdIdx = 8
        affinityIdx = 2
        meanBackgroundAffinityIdx = 3
        
        refP = refRes[,pIdx]
        refDbA = refRes[,dbAIdx]
        refAffinity = refRes[,affinityIdx]
        refMeanBackgroundAffinity = refRes[,meanBackgroundAffinityIdx]
        
        if(normalizeDbA == 1)
        {
          refStd = refRes[,stdIdx]
          refDbA = normalizeDbA2(refDbA, refStd)
        } else if(normalizeDbA == 2) {
          refDbA = (refAffinity - refMeanBackgroundAffinity) / sqrt(refAffinity ^ 2 + refMeanBackgroundAffinity ^ 2)
          refDbA[is.nan(refDbA)] = 0
        }
        
        dbAs = rbind2(dbAs, refDbA)
        ps = rbind2(ps, refP)
      }

      colnames(dbAs) = refRes$ID
      rownames(dbAs) = pwmFiles
      
      colnames(ps) = refRes$ID
      rownames(ps) = pwmFiles      
            
      dbAFile = file.path(potDir, "ref-dbA.tsv")
      write.table(t(dbAs), file=dbAFile, sep = "\t", quote = F, col.names = NA)
      
      pFile = file.path(potDir, "ref-p.tsv")
      write.table(t(ps), file=pFile, sep = "\t", quote = F, col.names = NA)      
    }
  } else {
    cat("Computing delta-dbA scores\n")
    if(normalizeDbA == 1)
    {
      cat("Normalizing dbA scores using standard deviations\n")
    } else if (normalizeDbA == 2) {
      cat("Normalizing dbA scores using relative difference\n")
    } else {
      cat("Using raw dbA scores\n")
    }
  
    resFiles = NULL
    
    for(i in 1:length(potentials))
    {
      pot = potentials[i]
      cat("Chemical potential =", pot, "\n")
  
      potDir = file.path("tmp", paste0("potential", pot))
      refDir = file.path(potDir, "ref")
      altDir = file.path(potDir, "alt")
      
      res = NULL    
      
      for(j in 1:length(pwmFiles))
      {
        pwm = pwmFiles[j]
  
        refRes = read.table(file.path(refDir, paste0(pwm, "_bindingP_0_randomBackground_", shuffleIters)), sep = "\t", stringsAsFactors = F, header = T, comment.char = "", 
                            check.names = F)
        
        refRes = refRes[order(refRes$ID),]
        altRes = read.table(file.path(altDir, paste0(pwm, "_bindingP_0_randomBackground_", shuffleIters)), sep = "\t", stringsAsFactors = F, header = T, comment.char = "", 
                            check.names = F)
        
        altRes = altRes[order(altRes$ID),]
        
        pIdx = 5
        dbAIdx = 4
        stdIdx = 8
        affinityIdx = 2
        meanBackgroundAffinityIdx = 3
        
        refP = refRes[,pIdx]
        altP = altRes[,pIdx]
        refDbA = refRes[,dbAIdx]
        altDbA = altRes[,dbAIdx]
        refAffinity = refRes[,affinityIdx]
        altAffinity = altRes[,affinityIdx]
        refMeanBackgroundAffinity = refRes[,meanBackgroundAffinityIdx]
        altMeanBackgroundAffinity = altRes[,meanBackgroundAffinityIdx]
        
        if(normalizeDbA == 1)
        {
          refStd = refRes[,stdIdx]
          altStd = altRes[,stdIdx]
          
          refDbA = normalizeDbA2(refDbA, refStd)
          altDbA = normalizeDbA2(altDbA, altStd)
        } else if(normalizeDbA == 2) {
          refDbA = (refAffinity - refMeanBackgroundAffinity) / sqrt((refAffinity + 1) ^ 2 + (refMeanBackgroundAffinity + 1) ^ 2)
          refDbA[is.nan(refDbA)] = 0
          altDbA = (altAffinity - altMeanBackgroundAffinity) / sqrt((altAffinity + 1) ^ 2 + (altMeanBackgroundAffinity + 1) ^ 2)
          altDbA[is.nan(altDbA)] = 0
        }
        
        dataRow = c(refP, altP, refDbA, altDbA)
        res = rbind2(res, dataRow)
      }
      
      colnames(res) = c(paste0(refRes$ID, "_p1"), paste0(refRes$ID, "_p2"), paste0(refRes$ID, "_dbA1"), paste0(refRes$ID, "_dbA2"))
      rownames(res) = pwmFiles
      resFile = file.path(potDir, "res.tsv")
      write.table(res, file=resFile, sep = "\t", quote = F, col.names = NA)
      resFiles = c(resFiles, resFile)
    }
  }
} else {
  cat("Using delta-dbA scores from 'tmp' folder\n")
  resFiles = NULL
  
  for(pot in potentials)
  {
    potDir = file.path("tmp", paste0("potential", pot))
    resFile = file.path(potDir, "res.tsv")   
    resFiles = c(resFiles, resFile)    
  }
}

if(onlyRef) {
  cat("The dbA and p-values for all chemical potentials, sequences and PWMs were put into 'tmp/potentialX' folders\n")
} else {
  cat("Integrating predictions using", integration, "...\n")
  if(is.na(pMeanDdbA)) {
    cat("Saving at most top", top, "PWMs\n")
  } else {
    cat("Saving PWMs with mean delta-dbA p-value <", pMeanDdbA, "\n")
    #top = numPWMs # do not perform top N filtering
  }
  
  source("code/r/predictionsIntegration.R")
  data = loadBindingData(resFiles, potentials)
  
  data$bd = data$bd[data$bd$mutName %in% seqNames,]
  
  if(useFiltering)
    data = filterData(data, pCut) # remove noisy entries
  
  #write.table(data$bd, file="ttt", sep="\t", col.names=!file.exists("ttt"), quote=F, row.names=F, append = T)
  
  extracted = extractData(data) # transform the data into an easier format
  
  meanDdbATable = reshape(extracted[,c("fileName", "mutName", "mean.ddba")], timevar = "mutName", idvar = "fileName", direction = "wide")
  colnames(meanDdbATable) = str_replace(colnames(meanDdbATable), "mean\\.ddba\\.", "")
  write.table(meanDdbATable, file=file.path("tmp", "mean.ddbA.tsv"), col.names = T, row.names = F, quote = F, sep="\t")
  
  pValScore = extracted$med.ddba
  
  meanDbAs = data.frame(fileName=extracted$fileName, score=pValScore)
  meanDbAs = meanDbAs[pValScore != 0,]
  if(nrow(meanDbAs) > 1)
  {
    meanDbAs = meanDbAs[order(meanDbAs$score),]
    meanDbAs$from = str_match(as.character(meanDbAs$fileName), "_from_([^_]+)")[,2]
    meanDbAs$base = str_match(as.character(meanDbAs$fileName), "^([^_]+)")[,2]
    meanDbAs$name = paste0(meanDbAs$base, "_", meanDbAs$from)
    #meanDbAs$name = meanDbAs$base
    N = nrow(meanDbAs)
    meanDbAs$uniqueUp = NA
    meanDbAs$uniqueDown = NA
    up = NULL
    down = NULL
    for (i in 1:N)
    {
      up = union(up, meanDbAs$name[i])
      meanDbAs$uniqueUp[i] = length(up)
      down = union(down, meanDbAs$name[N - i + 1])
      meanDbAs$uniqueDown[N - i + 1] = length(down)
    }
    
    pos = findInterval(pValScore, meanDbAs$score)
    #countsBelow = findInterval(abs(extracted$med.ddba), allMeanDdba)
    
    countsBelow = meanDbAs$uniqueUp[pos]
    countsBelow[pValScore > 0] = meanDbAs$uniqueDown[pos[pValScore > 0]]
    pVals = countsBelow
    Npos = sum(pValScore > 0)
    Nneg = N - Npos
    pVals[pValScore > 0] = pVals[pValScore > 0] / Npos
    pVals[pValScore < 0] = pVals[pValScore < 0] / Nneg
    pVals[pValScore == 0] = 1
    extracted$mean.ddba.pvalue = pVals
  } else {
    extracted$mean.ddba.pvalue = NA
  }
  
  pValsTable = reshape(extracted[,c("fileName", "mutName", "mean.ddba.pvalue")], timevar = "mutName", idvar = "fileName", direction = "wide")
  colnames(pValsTable) = str_replace(colnames(pValsTable), "mean\\.ddba\\.pvalue\\.", "")
  write.table(pValsTable, file=file.path("tmp", "mean.ddbA.p-values.tsv"), col.names = T, row.names = F, quote = F, sep="\t")
  cat("Mean delta-dbA scores (across all chemical potentials) and corresponding one-sided p-values for each mutation-PWM pair were put into 'tmp' folder\n")
  
  if(file.exists("ranking"))
    unlink("ranking", recursive = T)
  
  dir.create("ranking")
  # dump top N (or with p-value < pMeanDdbA) positively and negatively affected PWMs
  integratePredictions(extracted, length(potentials), top, "ranking", method=integration, pMeanDdbA)
  
  cat("PWM rankings for each SNP were put into 'ranking' folder\n")
}
