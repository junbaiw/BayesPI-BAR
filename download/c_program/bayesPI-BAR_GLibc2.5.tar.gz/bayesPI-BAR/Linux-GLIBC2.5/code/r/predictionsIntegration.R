library(stringr)

fixPWMNames = function(pwmNames)
{
  return(sub("\\.[^.]+$", "", basename(pwmNames)))
}


toChar = function(ff)
{
  if(class(ff) == "factor")
    return(levels(ff)[ff])
  
  return(as.character(ff))
}


loadBindingData = function(allPotentialFiles, potentials)
{
  potentials = paste0("pot", potentials)
  dataTypes = c("p1", "p2", "dbA1", "dbA2")
  
  res = NULL
  
  numMuts = NULL
  
  for(pot in 1:length(potentials))
  {
    bindingData = read.table(allPotentialFiles[pot], comment.char = "", check.names = F)
    
    numLoadedMuts = ncol(bindingData) / 4
    if(is.null(numMuts))
    {
      numMuts = numLoadedMuts
    } else {
      if(numMuts != numLoadedMuts)
      {
        stop(paste0("Error loading delta-dbA from tmp/ folder. Data for potential ", potentials[1], " has ", numMuts, " mutations, while data for potential ",
                    potentials[pot], " has ", numLoadedMuts, " mutations. The same number of mutations is expected for all chemical potentials."))
      }
    }
    
    colFields = str_split(colnames(bindingData), "_")
    colTypes = character(ncol(bindingData))
    for(i in 1:ncol(bindingData))
      colTypes[i] = colFields[[i]][length(colFields[[i]])]
    
    typeColumns = as.data.frame(lapply(dataTypes, function(x) which(colTypes == x)))
    names(typeColumns) = dataTypes
    
    if(is.null(res))
    {
      res = matrix(0, nrow = nrow(typeColumns) * nrow(bindingData), ncol = length(dataTypes) * length(potentials))
      nMuts = nrow(typeColumns)
      dataClass = expand.grid(fileName=fixPWMNames(rownames(bindingData)), n=1:nMuts)
      dataClass$mutName = gsub("_+p1", "", colnames(bindingData)[typeColumns[dataClass$n,1]])
      dataClass$n = NULL
      dataColumns = expand.grid(dataTypes, potentials)
      dataColumns = paste0(dataColumns[,2], ".", dataColumns[,1])
      
      fileNames = rep(rownames(bindingData), nrow(typeColumns))
    }
    
    for(i in 1:nrow(typeColumns))
    {
      idx = ((i - 1) * nrow(bindingData) + 1):(i * nrow(bindingData))
      for(j in 1:length(dataTypes))
        res[idx, (pot - 1) * length(dataTypes) + j] = bindingData[, typeColumns[i, j]]
    }
  }
  
  
  
  bindingData = as.data.frame(res)
  names(bindingData) = dataColumns
  bindingData = cbind2(bindingData, dataClass)
  bindingData$mutId = rep(1:nrow(typeColumns), each=nrow(bindingData)/nrow(typeColumns))

  bindingData = bindingData[!grepl("_disc", fileNames),]
  
  typeColumns = as.data.frame(lapply(dataTypes, function(x) grep(x, names(bindingData))))
  names(typeColumns) = dataTypes
  
  return(list(bd = bindingData, tc = typeColumns))
}


filterData = function(bd, pCut)
{
  p1Bad = bd$bd[, bd$tc$p1] > pCut
  bd$bd[, bd$tc$dbA1][p1Bad] = 0
  p2Bad = bd$bd[, bd$tc$p2] > pCut
  bd$bd[, bd$tc$dbA2][p2Bad] = 0
  
  bd$bd[, bd$tc$dbA1][bd$bd[, bd$tc$dbA1] < 0] = 0
  bd$bd[, bd$tc$dbA2][bd$bd[, bd$tc$dbA2] < 0] = 0
  
#   missingValues = rowSums(bd$bd[, bd$tc$dbA1] == 0) + rowSums(bd$bd[, bd$tc$dbA2] == 0)
#   numColumns = length(bd$tc$dbA1) + length(bd$tc$dbA2)
#   tooManyMissing = missingValues > numColumns * 0.2
#   bd$bd[tooManyMissing, bd$tc$dbA1] = 0
#   bd$bd[tooManyMissing, bd$tc$dbA2] = 0
  
  return(bd)  
}


extractData = function(bd)
{
  ds = bd$bd[,bd$tc$dbA2] - bd$bd[,bd$tc$dbA1]  
  
  ds[!is.finite(as.matrix(ds))] = NA  
  numPots = ncol(ds)
  
  data = cbind2(ds, bd$bd[, c("mutId", "fileName", "mutName")])
  data$med.p.ref = apply(bd$bd[,bd$tc$p1], 1, median)
  data$med.p.alt = apply(bd$bd[,bd$tc$p2], 1, median)  
  data$mean.ddba = apply(ds[,1:numPots], 1, mean)
  data$med.ddba = apply(ds[,1:numPots], 1, median)
  data = data[complete.cases(data),]
  return(data)
}


rankResult = function(r)
{
  if(nrow(r) > 0)
    r$rank = 1:nrow(r)
  else
    r$rank = numeric()

  return(r)
}

dumpBothWays = function(rankingFolder, rankPos, rankNeg, mutName)  
{
  resFile = file.path(rankingFolder, paste0(cleanName(mutName), ".tsv"))
  resPos = rankResult(rankPos)
  resNeg = rankResult(rankNeg)
  res = rbind2(resPos, resNeg)
  if(nrow(res) > 0)
  {
    res$change = "Positive"
    res$change[res[,"mean.ddba"] < 0] = "Negative"
  }
  else
    res = cbind2(data.frame(change=numeric()), res)
    
  write.table(res[,c("change", "rank", "fileName", "med.p.ref", "med.p.alt", "score", "mean.ddba", "mean.ddba.pvalue")], file=resFile, quote = F, 
              row.names = F, sep = "\t")
}

numUniqueNames = function(names)
{
  if(length(names) < 2)
    return(length(names))
  
  from = str_match(as.character(names), "_from_([^_]+)")[,2]
  base = str_match(as.character(names), "^([^_]+)")[,2]
  fullNames = paste0(base, "_", from)
  return(length(unique(fullNames)))
}

integratePredictions = function(data, numPots, top, rankingFolder, method, pMeanDdbA)
{
  totalPWMsInRanking = 0
  for(m in unique(data$mutId))
  {
    mm = data[data$mutId == m,]
    
    rank = function(r, s)
    {
      ranked = mm[order(r),]
      ranked = ranked[sign(ranked$mean.ddba) == s,]
      if(nrow(ranked) == 0)
        return(ranked)
      
      return(ranked[1:(min(nrow(ranked), top)),])
    }
    
    if(method == "pca")
    {
      if(nrow(mm) < 2 || sd(mm$mean.ddba) == 0)
        mscore = mm$mean.ddba
      else
      {
        ds = mm[,1:numPots]
        ds = log(abs(ds) + 1) * sign(ds)        
        mscore = princomp(ds)$scores[,1]    
        scoreSign = sign(cor(mscore, mm$mean.ddba))
        mscore = mscore * scoreSign
      }
    }
    else if(method == "mean")
      mscore = mm$mean.ddba
    else if(method == "median.ddba")
      mscore = mm$med.ddba
    else if(method == "median.rank")
      mscore = as.integer(apply(as.data.frame(lapply(mm[,1:numPots], function(x) base::rank(x, ties.method = "first") )), 1, median))
    else if(method == "rra")
    {
      library(RobustRankAggreg)
      rr = aggregateRanks(lapply(mm[,1:numPots], order), N = top)
      #rr = rr$Name[order(rr$Score)]
      rr = rr$Name[rr$Score > 0.999]
      rr = as.integer(levels(rr)[rr])
      mscore = numeric(nrow(mm))
      mscore[rr] = 1:length(rr)
      mscore[mscore == 0] = length(rr) / 2
    }
    else if(grepl("^pot\\.", method))
    {
      nPot = as.integer(substring(method, 5))
      if(nPot < 1 || nPot > numPots)
        stop(paste0("Selected chemical potential, ", nPot, ", is out of range. Allowed values are 1 .. ", numPots))
      
      mscore = mm[,nPot]
    }
    else
      stop(paste0("Unknown integration method: ", method))
    
    mm$score = mscore
        
    rankPos = rank(-mm$score, 1)
    rankNeg = rank(mm$score, -1)
    if(!is.na(pMeanDdbA)) {
      rankPos = rankPos[rankPos$mean.ddba.pvalue < pMeanDdbA,]
      rankNeg = rankNeg[rankNeg$mean.ddba.pvalue < pMeanDdbA,]
    }
    
    totalPWMsInRanking = totalPWMsInRanking + numUniqueNames(rankPos$fileName) + numUniqueNames(rankNeg$fileName)
    dumpBothWays(rankingFolder, rankPos, rankNeg, mm$mutName[1])
  }
  
  cat("There are", totalPWMsInRanking, "PWMs in the rankings")
}