library(stringr)

fastaFileName = commandArgs(T)[1]
cat("Input FASTA file:", fastaFileName, "\n")
fastaLines = readLines(fastaFileName)
pseudocount = 0.5

names = NULL
sequences = NULL

seq = ""

for(line in fastaLines)
{
  if(grepl("^>", line))
  {
    names = c(names, substring(line, 2))
    if(length(names) > 1)
      sequences = c(sequences, seq)
    
    seq = ""
  }
  else
    seq = paste0(seq, line, "\n")
}

if(seq != "")
  sequences = c(sequences, seq)

if(!file.exists("out"))
  dir.create("out")

for(i in 1:length(names))
{
  shortName = str_split(names[i], "\\s")[[1]][1]
  longName = gsub("\\s+$", "", names[i])
  longName = gsub("\t", '_from_', longName)
  longName = gsub("(#| |:)", '_', longName)
  longName = gsub("/", 'or', longName)
  outFile = file.path("out", paste0(longName, ".mlp"))
  
  sink(outFile)
  cat(paste0(shortName, "\t#\t", names[i], "\n"))
  cat('0.001     #       p-value\n')
  cat('8642     #       bonferroni\n')
  cat('0\t1\t1\t1\t1\t0\t1\t1\t1\t1 # derived from leading strand\n')
  cat('#\ta\tc\tg\tt\tP=>P/0.25\n');
  seqs = str_split(sequences[i], "\n")[[1]]
  for(j in 1:length(seqs))
  {
    if(str_length(seqs[j]) == 0)
      next
    
    line = str_split(seqs[j], " ")[[1]]
    weights = as.numeric(line[2:length(line)]) * 4 + pseudocount
    cat(paste0(line[1], "\t", paste0(weights, collapse = "\t"), "\n"))
  }
  
  sink()
}