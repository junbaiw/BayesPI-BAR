# TF aliases
tfNameMap = list()

tfNameMap[['NFKB']]=c('NFKB', "NF-kappaB")
tfNameMap[['NRF2']]=c('NRF2', 'NFE2L2', 'NFE2', 'NRF-2')
tfNameMap[['NFY']]=c('NFY', "NF-Y")
tfNameMap[['YY1']]=c('YY1')
tfNameMap[['USF1']]=c('USF')
tfNameMap[['USF-1']]=c('USF')
tfNameMap[['USF2']]=c('USF')
tfNameMap[['c-MYB']]=c('MYB')
tfNameMap[['c-MYB']]=c('MYB')
tfNameMap[['C-MYB']]=c('MYB')
tfNameMap[['IRF1']]=c('IRF1','IRF-1')
tfNameMap[['HLF']]=c('HLF')
tfNameMap[['P53']]=c('P53')
tfNameMap[['p53']]=c('P53')
tfNameMap[['HNF-1']]=c('HNF1')
tfNameMap[['HNF.1']]=c('HNF1')
tfNameMap[['USF']]=c('USF')
tfNameMap[['SPI1']]=c('SPI1')
tfNameMap[['PU.1']]=c('SPI1')


tfNameMap[['AP-2alpha']]=c('AP-2','AP2','TFAP2','AP2TF')
tfNameMap[['AP-2-alpha']]=c('AP-2','AP2','TFAP2','AP2TF')
tfNameMap[['AP.2alpha']]=c('AP-2','AP2','TFAP2','AP2TF')
tfNameMap[['AP-2gamma']]=c('AP-2','AP2','TFAP2','AP2TF')
tfNameMap[['AP-2-ALPHA']]=c('AP-2','AP2','TFAP2','AP2TF')
tfNameMap[['AP-2ALPHA']]=c('AP-2','AP2','TFAP2','AP2TF')
tfNameMap[['CCAAT']]=c('CRP1', 'CCAAT', 'CEBPZ', 'CEBPA', 'CEBPG', 'CEBPB', 'CEBP', "C/EBP")
tfNameMap[['CACCC']]=c('CACCC','EKLF','KLF1','KLF-1','KLF')
tfNameMap[['SP1']]=c('SP1','SP-1','TFSP1')
tfNameMap[['SP-1']]=c('SP1','SP-1','TFSP1')
tfNameMap[['Sp1']]=c('SP1','SP-1','TFSP1')
tfNameMap[['MSX1']]=c('MSX1','MSX-1','HOX7','ECTD3','HYD1','STHAG1')
tfNameMap[['GATA-1']]=c('GATA')
tfNameMap[['GATA-A']]=c('GATA')
tfNameMap[['GATA.1']]=c('GATA')
tfNameMap[['GATA.A']]=c('GATA')
tfNameMap[['HNF-4']]=c('HNF4a','HNF4g','HNF4','TCF14','TCF-14','MODY','MODY1')
tfNameMap[['HNF.4']]=c('HNF4a','HNF4g','HNF4','TCF14','TCF-14','MODY','MODY1')
tfNameMap[['C/EBP']]=c('CRP1', 'CEBP', 'CCAAT', "C/EBP")
tfNameMap[['C.EBP']]=c('CRP1', 'CEBP', 'CCAAT', "C/EBP")
tfNameMap[['CEBP']]=c('CRP1', 'CEBP', 'CCAAT', "C/EBP")
tfNameMap[['CEBP-delta']]=c('CRP1', 'CEBP', 'CCAAT', "C/EBP")
tfNameMap[['CEBP-DELTA']]=c('CRP1', 'CEBP', 'CCAAT', "C/EBP")
tfNameMap[['SIX3']]=c('SIX3','HPE2','SIX','SIX-3','HPE-2')
tfNameMap[['Six3']]=c('SIX3','HPE2','SIX','SIX-3','HPE-2')

tfNameMap[['AR']]=c('_AR_', "^ar$")
tfNameMap[['BCL11A']]=c('BCL11A')
tfNameMap[['c-Fos']]=c('AP1_', 'AP-1')
tfNameMap[['c-FOS']]=c('AP1_', 'AP-1')
tfNameMap[['C-FOS']]=c('AP1_', 'AP-1')
tfNameMap[['JunD']]=c('AP1_')
tfNameMap[['c-Myc']]=c('MYC')
tfNameMap[['Max']]=c('MYC')
tfNameMap[['c-Rel']]=c('REL_', 'c-Rel')
tfNameMap[['C-REL']]=c('REL_', 'c-Rel')
tfNameMap[['CCNT2']]=c('CCNT2')
tfNameMap[['E2F6']]=c('E2F')
tfNameMap[['HA-E2F1']]=c('E2F')
tfNameMap[['EBF']]=c('EBF')
tfNameMap[['EBF1']]=c('EBF')
tfNameMap[['Egr1']]=c('EGR1', "Egr-1")
tfNameMap[['EGR1']]=c('EGR1', "Egr-1")
tfNameMap[['ELF1']]=c('ELF1')
tfNameMap[['ETS']]=c('ETS')
tfNameMap[['FOXA1']]=c('FOXA')
tfNameMap[['GABP']]=c('GABP')
tfNameMap[['HEY1']]=c('HEY1')
tfNameMap[['MEF2A']]=c('MEF2')
tfNameMap[['MYF-5']]=c('MYF')
tfNameMap[['Oct-1']]=c('POU2F2', "OCT")
tfNameMap[['Oct-2']]=c('POU2F2', "OCT")
tfNameMap[['OCT-1']]=c('POU2F2', "OCT")
tfNameMap[['POU2F2']]=c('POU2F2', "OCT")
tfNameMap[['p300']]=c('P300')
tfNameMap[['PAX5-C20']]=c('PAX5')
tfNameMap[['RXRA']]=c('RXRA')
tfNameMap[['SOX10']]=c('SOX10')
tfNameMap[['SRY']]=c('SRY')
tfNameMap[['STAT1']]=c('STAT')
tfNameMap[['STAT3']]=c('STAT')
tfNameMap[['TAF1']]=c('TATA')
tfNameMap[['TBP']]=c('TATA', "TBP")
tfNameMap[['TCF4']]=c('TCF4', "TCF-4")
tfNameMap[['TEL2']]=c('ETV7')
tfNameMap[['TR4']]=c('NR2C2')
tfNameMap[['ZBTB7A']]=c('ZBTB7A')

isTfCorrect = function(tf, fileName)
{
  if(!(tf %in% names(tfNameMap)))
    stop(paste0("Unknown TF: ", tf))
  
  for(tfName in tfNameMap[[tf]])
    if(length(grep(tfName, fileName, ignore.case = T)) > 0)
      return(T)
  
  return(F)
}

if(!("stringr" %in% installed.packages()))
  install.packages("stringr", repos = "http://cran.us.r-project.org")

library(stringr)
source("code/r/misc.R")

top = 10
rankingFolder = "ranking"

top = as.integer(getArgParam("top", top))
rankingFolder = getArgParam("ranking", rankingFolder)
directed = getArgBool("directed")

if(!file.exists(rankingFolder))
  stop(paste("Folder", rankingFolder, "not found"))

cat("Reading rankings from", rankingFolder, "\n")

# Test saved rankings
allMutsFiles = dir(rankingFolder, ".*\\.tsv$")
cat(length(allMutsFiles), "mutation rankings found\n")
fields = str_split(str_replace(allMutsFiles, "\\.tsv$", ""), "_")
dirs = sapply(fields, function(ff)
  {
    fff = str_split(ff[-1], "\\|")
    return(sapply(fff, function(ffff) if(length(ffff) == 1) "" else ffff[2]))
  })

fields = sapply(fields, function(ff) str_replace(ff, "(\\||=)((GAIN)|(LOSS)|(UNKNOWN))$", ""))
mutTFs = sapply(fields, function(ff) ff[!(ff %in% strtoi(1:10))][-1])

for(i in 1:length(mutTFs))
  for(j in 1:length(mutTFs[[i]]))
    if(dirs[[i]][j] == "")
      dirs[[i]][j] = dirs[[i]][length(dirs[[i]])]

allTFs = sort(unique(unlist(mutTFs)))
unknownTFs = allTFs[!(allTFs %in% names(tfNameMap))]
mutTFs = sapply(mutTFs, function(ff) ff[!(ff %in% unknownTFs)])
unknownMuts = sapply(mutTFs, function(ff) length(ff) == 0)
if(directed)
  unknownMuts = unknownMuts | sapply(dirs, function(dd) sum(dd == "GAIN" | dd == "LOSS") == 0)

if(sum(unknownMuts) > 0)
{
  if(directed)
    cat("The following mutations have unknown TFs or unknown directions and will be skipped:", allMutsFiles[unknownMuts], "\n")
  else {
    cat("The following mutations have unknown TFs and will be skipped:", allMutsFiles[unknownMuts], "\n")
  }

  allMutsFiles = allMutsFiles[!unknownMuts]
  mutTFs = mutTFs[!unknownMuts]
  dirs = dirs[!unknownMuts]
  cat(length(allMutsFiles), "mutation rankings left to be tested\n")
}

minRank = rep(NA, length(mutTFs))
bestScore = rep(NA, length(mutTFs))
for(i in 1:length(allMutsFiles))
{
  ranking = read.table(file.path(rankingFolder, allMutsFiles[i]), sep="\t", header=T)
  #ranking$rank[ranking$change == "Positive"] = sample.int(sum(ranking$change == "Positive"))
  #ranking$rank[ranking$change == "Negative"] = sample.int(sum(ranking$change == "Negative"))
  if(nrow(ranking) == 0)
    next
    
  ranking$correct = F
  for(j in 1:nrow(ranking))
    for(k in 1:length(mutTFs[[i]]))
    {
      tf = mutTFs[[i]][k]
      if(isTfCorrect(tf, ranking$fileName[j]))
      {
        if(!directed || dirs[[i]][k] != "UNKNOWN" && (dirs[[i]][k] == "GAIN") == (ranking$change[j] == "Positive"))
          ranking$correct[j] = T
        
        break
      }
    }
  
  if(sum(ranking$correct) > 0)
  {
    minRank[i] = min(ranking$rank[ranking$correct])
    bestScore[i] = ranking$score[ranking$rank == minRank[i] & ranking$correct][1]
  }
}

fredrikssonMuts = c("TERT_ETS|GAIN_1", "TERT_ETS|GAIN_2", "TERT_ETS|GAIN_3", "TERT_ETS|GAIN_4")

hgmdMuts = c("ADAMTS18_TEL2|GAIN", "CDKN2B-AS1_STAT1|LOSS", "CHGB_SRY|LOSS_YY1|LOSS", 
             "CHGB_c-FOS|LOSS", "CHRNA3_Oct-1|LOSS", "FABP4_C/EBP|LOSS", "FAS_c-Rel|GAIN", 
             "FMO1_YY1|LOSS", "FOXE1_MYF-5|LOSS", "FOXE1_USF1|GAIN_USF2|GAIN", 
             "FZD1_Egr1|GAIN", "GFI1B_Oct-1|LOSS", "GFI1B_GATA-1|LOSS", "GSTM1_AP-2-alpha|LOSS", 
             "HBG2_GATA-1|LOSS", "IGF1_C/EBP-delta|LOSS", 
             "IL18_OCT-1|GAIN", "IL4_Oct-1|LOSS", "LEP_Sp1|GAIN", "MPZ_SOX10|LOSS", 
             "MYC_TCF4|GAIN_beta-catenin|GAIN", "PVT1_YY1|LOSS", 
             "SIRT1_p53|LOSS", "SLC47A1_Sp1|LOSS", "SLC7A1_Sp1|LOSS", "SORT1_C/EBP|GAIN", 
             "TMPRSS2_AR|LOSS", "UGT1A7_TBP|LOSS", "UGT2B17_FOXA1|GAIN")

andersonEpsteinMuts = c("AFP_HNF-1_1|GAIN", "AFP_HNF-1_2|GAIN", "AGTRL1_SP1|GAIN", 
                        "ALOX15_SPI1|GAIN", "CETP_SP1|UNKNOWN", "COL1A1_Sp1|UNKNOWN", 
                        "F9_CEBP|LOSS", "F9_HLF|UNKNOWN", "F9_HNF-4|UNKNOWN", "FECH_SP1|LOSS", 
                        "FLT1_P53|GAIN", "FTH1_NFY|UNKNOWN", "GP1BB_GATA-1|LOSS", "GPD2_NRF2|UNKNOWN", 
                        "HBB_CACCC_1|UNKNOWN", "HBB_CACCC_2|UNKNOWN", "HBB_CACCC_3|UNKNOWN", 
                        "HBB_CACCC_4|UNKNOWN", "HBB_CACCC_5|UNKNOWN", "HBB_CCAAT|UNKNOWN", 
                        "HBM_GATA-1|GAIN", "HOXB7_USF1|UNKNOWN", "IRF2_IRF1|LOSS", "IRF6_AP-2alpha|LOSS", 
                        "ITGA2_SP1|LOSS", "LIPC_USF|LOSS", "NFKBIL1_USF1|LOSS", "OPRM1_NFKB|UNKNOWN", 
                        "PKLR_GATA-A|LOSS", "PTGS2_c-MYB|GAIN", "SFTPB_SP-1|GAIN", "SOX9_MSX1|UNKNOWN", 
                        "SP1_NFY|UNKNOWN", "TCOf1_YY1|LOSS")

fredrikssonMuts = c(fredrikssonMuts, cleanName(fredrikssonMuts))
hgmdMuts = c(hgmdMuts, cleanName(hgmdMuts))
andersonEpsteinMuts = c(andersonEpsteinMuts, cleanName(andersonEpsteinMuts))

fredrikssonMuts = c(fredrikssonMuts, toupper(fredrikssonMuts))
hgmdMuts = c(hgmdMuts, toupper(hgmdMuts))
andersonEpsteinMuts = c(andersonEpsteinMuts, toupper(andersonEpsteinMuts))


cat("Considering top", top, "TFs, directed:", directed, "\n")

printAccuracy = function(name, ranks)
{
  right = sum(ranks <= top, na.rm = T)
  rightPercent = right / length(ranks)
  cat(name, ":", right, "of", length(ranks), "(", rightPercent * 100, "%) are correct\n")
}

printAccuracy2 = function(name, ranks)
{
  n = length(ranks)
  ranks = ranks[!is.na(ranks)]
  ranks = ranks[ranks <= top]
  ranks = c(ranks, rep(top + 1, n - length(ranks)))
  
  cat(name, ": mean rank =", mean(ranks), ", median rank =", median(ranks), "\n")
}

printAccuracy("Overall", minRank)
printAccuracy("Anderson + Epstein", minRank[allMutsFiles %in% paste0(andersonEpsteinMuts, ".tsv")])
printAccuracy("Fredriksson", minRank[allMutsFiles %in% paste0(fredrikssonMuts, ".tsv")])
printAccuracy("HGMD", minRank[allMutsFiles %in% paste0(hgmdMuts, ".tsv")])
allKnown = allMutsFiles %in% paste0(c(hgmdMuts, andersonEpsteinMuts, fredrikssonMuts), ".tsv")
printAccuracy("All known", minRank[allKnown])

cat("Mean top rank scores:\n")
printAccuracy2("Overall", minRank)
printAccuracy2("Anderson + Epstein", minRank[allMutsFiles %in% paste0(andersonEpsteinMuts, ".tsv")])
printAccuracy2("Fredriksson", minRank[allMutsFiles %in% paste0(fredrikssonMuts, ".tsv")])
printAccuracy2("HGMD", minRank[allMutsFiles %in% paste0(hgmdMuts, ".tsv")])
printAccuracy2("All known", minRank[allKnown])

write.table(data.frame(mutation = allMutsFiles[allKnown], bestRank = minRank[allKnown], bestScore = bestScore[allKnown]),
            file = "ranks.tsv", sep = "\t", quote = F, col.names = T, row.names = F)





