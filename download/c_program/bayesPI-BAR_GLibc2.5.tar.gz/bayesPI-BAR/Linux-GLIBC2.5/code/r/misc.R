library(stringr)

if(Sys.getenv("COLUMNS") != "")
  options(width=as.integer(Sys.getenv("COLUMNS")))

args = commandArgs(T)

getArgParam = function(argName, defVal)
{
  arg = paste0("-", argName)
  idx = grep(arg, args)
  if(length(idx) > 1)
    stop(paste0(arg, " specified more than once"))
  
  if(length(idx) == 1)
  {
    if(idx == length(args))
      stop(paste0("Missing value for ", arg))
    
    return(args[idx + 1])
  }
  
  return(defVal)
}

getArgBool = function(argName)
{
  arg = paste0("-", argName)
  idx = grep(arg, args)
  if(length(idx) > 1)
    stop(paste0(arg, " specified more than once"))
  
  return(length(idx) == 1)
}

illegalChars = paste0("\\", str_split("/\\:,;'\"?*", "")[[1]])

cleanName = function(name)
{
  for(ic in illegalChars)
    name = str_replace_all(name, ic, "")
  
  if(.Platform$OS.type == "windows")
    name = str_replace_all(name, "\\|", "=")
  
  return(name)
}