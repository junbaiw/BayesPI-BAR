potentials = as.integer(readLines("potentials"))
cat(length(potentials), "chemical potentials selected:", potentials, "\n")

source("code/r/misc.R")

top = 100
rankingFolder = "ranking/"

top = as.integer(getArgParam("top", top))
directed = getArgBool("directed")


for(pot in 1:length(potentials))
{
  system2("./runDemo.sh", c("-noRecompute", "-noFilter", "-top", top, paste0("-integration pot.", pot)))
  system2("./checkAccuracy.sh", c("-top", top, if(directed) "-directed" else ""))
  file.rename("ranks.tsv", paste0("ranks.pot.", potentials[pot], ".tsv"))
}

cat("Results for individual chemical potentials have been saved in files:", paste0("ranks.pot.", potentials, ".tsv", collapse = ", "), "\n")