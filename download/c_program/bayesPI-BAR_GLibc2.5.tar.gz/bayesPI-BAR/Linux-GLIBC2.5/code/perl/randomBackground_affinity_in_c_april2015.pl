#!/usr/bin/perl -w

use strict;
use Getopt::Long; 
use Cwd;
use POSIX qw(ceil);
use File::Spec::Functions;

#read parameters
use vars map {"\$opt_$_"} qw(potential override_potential normalize numP seqFile psamFolder loops seed);

GetOptions qw(potential=s override_potential=s normalize=s numP=s seqFile=s psamFolder=s loops=s seed=s);
print "must specify -seqFile <file> for input sequences\n" and die unless defined $opt_seqFile;
print "must specify -psamFolder <folder> for input PSAM matrix folder\n" and die unless defined $opt_psamFolder;
print "must specify -loops <number> for the number of permutation tests\n" and die unless defined $opt_loops;
print "must specify -numP <number> for the number of processors are used in the calculation\n" and die unless defined $opt_numP;

if (not defined $opt_normalize) {
	$opt_normalize = 2;
}

if (not defined $opt_potential) {
	$opt_potential = 0;
}

if (not defined $opt_override_potential) {
	$opt_override_potential = 1;
}

if (not defined $opt_seed) {
	$opt_seed = 1;
}

opendir DIR, $opt_psamFolder or die "cannot open dir $opt_psamFolder: $!";
my @files = grep { $_ ne '.' && $_ ne '..' && /\.mlp$/} readdir DIR;
closedir DIR;

my $matCount = scalar @files;
print "$matCount matrices found\n";

my $batchSize = int(ceil($matCount / $opt_numP));
print "Batch size: $batchSize\n";

my @pids=();



#loop in processors
for (my $job = 0; $job < $opt_numP; $job++) {
	die  "could not fork" unless defined(my $pid = fork);
	unless ($pid) {
		my $from = $job * $batchSize;
		my $to = min(($job + 1) * $batchSize - 1, $matCount - 1);
		for(my $i = $from; $i <= $to; $i++) {
			my $pwmFile = catfile($opt_psamFolder, $files[$i]);
			my @args=("./code/bin/bayesPI_affinity", "-oNum=0", "-normalize=$opt_normalize", "-potential=$opt_potential", "-override_potential=$opt_override_potential", 
				"-dependence=0", "-strand=2", "-psam=$pwmFile", "-seq=$opt_seqFile", "-shuffle=$opt_loops", "-seed=$opt_seed");
			system(@args)==0 or die "system  @args failed: $?";
		}
		
		die "\tDone $job from $from to $to";
	}
	push @pids, $pid;
	print "processing $pid $job \n";
} 

foreach (@pids) {
	my $temp= waitpid($_,0);
	print "Done with pid $temp \n";
}



sub max ($$) { $_[$_[0] < $_[1]] }
sub min ($$) { $_[$_[0] > $_[1]] }